#!/usr/bin/env python3
"""Кераміка України — безкоштовний локальний сервер пульта.
Запуск: python server.py
Стандартна бібліотека Python; інтернет не потрібен.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import json, secrets, threading, socket, io, webbrowser, os, time, sys
sys.path.insert(0,str(Path(__file__).resolve().parent / "vendor"))

ROOT=Path(__file__).resolve().parent
PORT=int(os.environ.get('KERAMIKA_PORT','8765'))
KEY=secrets.token_urlsafe(16)
LOCK=threading.Lock()
ROOMS={'povna':{'seq':0,'commands':[],'state':None},'vyshkil':{'seq':0,'commands':[],'state':None}}

def local_ip():
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(('192.0.2.1',80))
        a=s.getsockname()[0];s.close();return a
    except OSError:
        try:return socket.gethostbyname(socket.gethostname())
        except OSError:return '127.0.0.1'
IP=local_ip()
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
    def end_headers(self):
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        super().end_headers()
    def do_GET(self):
        u=urlparse(self.path);p=u.path;q=parse_qs(u.query)
        if p=='/api/health':return self.respond({'server':'keramika-lan-v1'})
        room=q.get('room',[''])[0]
        if p in ('/api/pair','/api/commands','/api/state','/api/qr'):
            if room not in ROOMS:return self.respond({'error':'invalid room'},400)
            with LOCK:
                r=ROOMS[room]
                if p=='/api/pair':
                    url=f'http://{IP}:{PORT}/pilot.html?room={room}&key={KEY}'
                    return self.respond({'url':url,'seq':r['seq']})
                if p=='/api/state':return self.respond(r['state'] or {})
                if p=='/api/commands':
                    try:after=int(q.get('after',['0'])[0])
                    except ValueError:after=0
                    return self.respond({'commands':[x for x in r['commands'] if x['seq']>after]})
            if p=='/api/qr':
                try:
                    import qrcode
                    from qrcode.image.svg import SvgImage
                    addr=f'http://{IP}:{PORT}/pilot.html?room={room}&key={KEY}'
                    out=io.BytesIO();qrcode.make(addr,image_factory=SvgImage,box_size=5,border=3).save(out)
                    data=out.getvalue();self.send_response(200);self.send_header('Content-Type','image/svg+xml');self.send_header('Content-Length',str(len(data)));self.end_headers();return self.wfile.write(data)
                except ImportError:return self.respond({'error':'qrcode module is optional'},404)
        return super().do_GET()
    def do_POST(self):
        u=urlparse(self.path)
        if u.path not in ('/api/action','/api/state'):return self.respond({'error':'unknown endpoint'},404)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0<size<10000:raise ValueError('bad content length')
            data=json.loads(self.rfile.read(size))
            room=data.get('room')
            if room not in ROOMS:raise ValueError('invalid room')
            if u.path=='/api/action':
                if data.get('key')!=KEY:return self.respond({'error':'bad key'},403)
                action=data.get('action')
                if action not in ('prev','next','jump'):raise ValueError('invalid command')
                index=data.get('index')
                if action=='jump' and (type(index)!=int or index<0 or index>1000):raise ValueError('invalid index')
                with LOCK:
                    r=ROOMS[room];r['seq']+=1;c={'seq':r['seq'],'action':action}
                    if action=='jump':c['index']=index
                    r['commands'].append(c);r['commands']=r['commands'][-200:]
            else:
                state={k:data[k] for k in ('index','total','title','sections') if k in data}
                state['updated']=int(time.time())
                with LOCK:ROOMS[room]['state']=state
            return self.respond({'ok':True})
        except (ValueError,KeyError,TypeError,json.JSONDecodeError) as e:return self.respond({'error':str(e)},400)
    def respond(self,obj,status=200):
        b=json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def log_message(self,fmt,*args):
        if not self.path.startswith('/api/'):super().log_message(fmt,*args)

if __name__=='__main__':
    try:
        server=ThreadingHTTPServer(('0.0.0.0',PORT),Handler)
    except OSError as e:
        print(f'Не вдалося запустити сервер на порту {PORT}: {e}');raise SystemExit(1)
    print('КЕРАМІКА УКРАЇНИ — ЛОКАЛЬНИЙ ПУЛЬТ')
    print('Комп’ютер: http://localhost:%d/'%PORT)
    print('Телефон: під’єднайтеся до тієї самої мережі Wi-Fi.')
    print('Приблизна IP-адреса комп’ютера:',IP)
    print('Залиште це вікно відкритим під час показу. Для виходу — Ctrl+C.')
    try:
        webbrowser.open(f'http://localhost:{PORT}/')
        server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
